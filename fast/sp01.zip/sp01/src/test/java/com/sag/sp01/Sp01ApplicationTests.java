package com.sag.sp01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
